var jwt = require('jsonwebtoken');

module.exports = function authenticate(req,res,next){
  var token = req.body.token || req.query.token || req.headers['x-access-token'];
  // decode token
  if (token) {
    // verifies secret and checks exp
    jwt.verify(token,"test", function(err, decoded) {
      if (err) {
        console.log(err);
        return res.status(401).send({
            success: false,
            message: 'Not Authorized'
        });
      } else {
        // if everything is good, save to request for use in other routes
        req.body.token = decoded;
        next();
      }
    });
  }else {
    // if there is no token
    // return an error
    return res.status(403).send({
      success: false,
      message: 'You dont have permission to access this'
    });
  }
};
