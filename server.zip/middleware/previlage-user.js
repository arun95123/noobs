const userDetailsController = require('../controllers').UserDetails;

module.exports = function previlageUser(req, res, next){
  var token = req.body.token;
  // decode token
  if (token) {
    // verifies secret and checks exp
  userDetailsController.list(req)
    .then(userDetails => {
      if(userDetails.user_type==2){
          next();
      }else{
        return res.status(403).send({
          success: false,
          message: 'You dont have permission to access this'
        });;
      }
    })
    .catch(error => {
      console.log(error);
      res.status(500).send();
    });
  }else {
    // if there is no token
    // return an error
    return res.status(401).send({
        success: false,
        message: 'Not Authorized'
    });
  }
};
