const _ = require('lodash') ;
const express = require('express');
const router=express.Router();
const UserDetailsController = require('../controllers').UserDetails;
const previlageUser = require('../middleware/previlage-user');
const authenticate = require('../middleware/authenticate');

router.post('/', (req, res) => {
    UserDetailsController.create(req.body)
      .then(userdetails => {
        const response = {
          success: true,
          user_id :userdetails.id
        }
        res.status(201).send(response)
      })
      .catch(error => res.status(400).send({success: false}))
});

router.get('/',authenticate, (req, res) => {
  UserDetailsController.getData(req.body)
    .then(userdetails => {
      if(_.isEmpty(userdetails)){
        res.status(404).send({
          success: false,
          message: 'User not found'
        });
      }
      const response = {
        success: true,
        data: userdetails
      }
      res.status(200).send(response);
    })
    .catch(err => res.status(500).send({success: false, message : "Internal server error . Please try after sometime."}))
});

module.exports = router;
