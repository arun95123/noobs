const express = require('express');
const router=express.Router();
const userDetailsController = require('../controllers').UserDetails;
const takeCourseController = require('../controllers').takeCourse;
const CourseController = require('../controllers').course;
const previlageUser = require('../middleware/previlage-user');
const authenticate = require('../middleware/authenticate');

router.post('/course', authenticate,CourseController.create);
router.post('/takeCourse', authenticate,CourseController.takeCourse);
router.post('/assignCourse', authenticate,CourseController.assignCourse);

router.get('/userDetails', authenticate, userDetailsController.getData);
router.get('/course',authenticate, CourseController.list);

module.exports = router;
