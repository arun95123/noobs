const _ = require('lodash') ;
const express = require('express');
const router=express.Router();
const LoginController = require('../controllers').login;
const previlageUser = require('../middleware/previlage-user');
const authenticate = require('../middleware/authenticate');
var bcrypt = require('bcrypt-nodejs');
var jwt    = require('jsonwebtoken');



router.post('/', (req, res) => {
    LoginController.loginUser(req.body)
      .then(login => {
      var response={};
      if (_.isEmpty(login)) {
          response.success=false;
          response.message = "user not found";

      }
      if(bcrypt.compareSync(req.body.password, login.password)){
        var token = jwt.sign(login.loginDetailId,"test");
        response.success=true;
         response.token =  token ;
      }else{
        response.success= false;
        response.message = "username or password incorrect";
      }
		res.status(200).send(response)
    })
      .catch(error => {console.log(error);res.status(500).send({success: false, message : "Internal server error. Please try later."});})
});

module.exports = router;
