const _ = require('lodash') ;
const express = require('express');
const router=express.Router();
const AnnouncementController = require('../controllers').announcement;
const previlageUser = require('../middleware/previlage-user');
const authenticate = require('../middleware/authenticate');

router.post('/',authenticate, previlageUser, (req, res) => {
    AnnouncementController.create(req.body)
      .then(announcement => {
        const response = {
          success: true,
          data :announcement
        }
        res.status(201).send({response})
      })
      .catch(error => res.status(400).send({success: false}))
});

router.get('/',authenticate, (req, res) => {
  AnnouncementController.findByCourseId(req.query.courseId)
    .then(announcements => {
      if(_.isEmpty(announcements)){
        res.status(404).send({
          success: false,
          message: 'Record not found'
        });
      }
      const response = {
        success: true,
        data: announcements
      }
      res.status(200).send({response});
    })
    .catch(err => res.status(400).send)
});

module.exports = router;
