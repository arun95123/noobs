const LoginDetails = require('../models').logindetails;



function loginUser(data) {

  return LoginDetails
    .findOne({where : {user_name : data.user_name}})
    .then(login =>  login)
    .catch(error => {
      console.log(error);
    }
    );
}

module.exports = {
  loginUser
};
