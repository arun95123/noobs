const Course = require('../models').course;
const UserDetails = require('../models').userdetails;

const CourseJoin = Course.belongsTo(UserDetails, { as :'instructor', foreignKey: 'instructorId'});


const courseToUser = Course.belongsToMany(UserDetails, {through: 'usertocourse'});
const userToCourse = UserDetails.belongsToMany(Course, {through: 'usertocourse'});
function create(req, res) {
  console.log(req.body.token)
  return Course
    .create({
      course_name: req.body.course_name,
      start_date: req.body.start_date,
      completion_date: req.body.completion_date,
      created_by: req.body.token,
      instructorId : req.body.token

    },{
        include: [ CourseJoin]
      })
    .then(course => res.status(201).send({success: true,data :course}))
    .catch(error => res.status(400).send({success: false}));
}

function list(req, res) {
  return Course
    .all({include : [{model : UserDetails, as : 'instructor'}]})
    .then(course => res.status(200).send({success: true,data :course}))
    .catch(error => {console.log(error);res.status(400).send({success: false})});
}


function takeCourse(req,res){
   return Course.findById(req.body.course_id).then(course=>{

    course.setUserdetails([req.body.token]).then(sc=>{
        console.log(sc);
        res.status(200).send({success: true, result : sc})
    })
    .catch(error => {console.log(error);res.status(400).send({success: false});});
});
}


function assignCourse(req,res){
  console.log("herere" + req.body.user_ids);
   return Course.findById(req.body.course_id).then(course=>{
    var user_id =req.body.user_id;
    course.setUserdetails(user_id).then(sc=>{
        console.log(sc);
        res.status(200).send({success: true, result : sc})
    })
    .catch(error => {console.log(error);res.status(400).send({success: false});});
});
}
module.exports = {
  create,
  list,
  takeCourse,
  assignCourse
};
