const UserDetails = require('./userDetails');
const login = require('./login');
const course = require('./course');
const takeCourse = require('./takeCourse');
const announcement = require('./announcement');

module.exports = {
  UserDetails,
  login,
  course,
  takeCourse,
  announcement
};
