const UserDetails = require('../models').userdetails;
const LoginDetails = require('../models').logindetails;
const UserJoin = UserDetails.hasOne(LoginDetails, { as :'login_details'});

function create(data) {
  return UserDetails
    .create({
      first_name: data.first_name,
      last_name: data.last_name,
      email: data.email,
      dob: data.dob,
      user_type : data.user_type,
      login_details: [{
        user_name: data.user_name,
        password: data.password
      }]
      },
      {
        include: [ UserJoin]
      }
    )
    .then(userDetails => userDetails)
    .catch(error => {
       console.log(error);
      return reject();
    });
}

function list(req) {
  return UserDetails
    .findOne({where : {id : req.body.token}})
}

function getData(data) {
  return UserDetails
    .findOne({where : {id : data.token}})
    .then(userDetails => res.status(200).send(userDetails));
}
module.exports = {
  create,
  list,
  getData
};
