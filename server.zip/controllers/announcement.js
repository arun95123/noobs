const _ = require('lodash') ;
const Announcement = require('../models').announcement;
const UserDetails = require('../models').userdetails;

function create(data) {
  return new Promise(function (resolve, reject) {
    if(_.isEmpty(data.announcementTitle) || _.isEmpty(data.token) || _.isNil(data.courseId)){
      reject();
    }
    Announcement.create({
      announcement_title: data.announcementTitle,
      announcement_content: data.announcementContent,
      created_by: data.token,
      course_id : data.courseId
    })
    .then(announcement => resolve(announcement))
    .catch(err => {
      console.log(err);
      return reject();
    });
  });
}

function findByCourseId(courseId) {
  return Announcement.findAll({
    where: {
      course_id: courseId
    },
    include: [{
      model: UserDetails
    }]
  })
  .then(announcements => announcements)
  .catch(err => console.log(err));
}

module.exports = {
  create,
  findByCourseId
};
