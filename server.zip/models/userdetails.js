'use strict';

module.exports = (sequelize, DataTypes) => {
  const UserDetails = sequelize.define('userdetails', {
      first_name: DataTypes.STRING,
      last_name: DataTypes.STRING,
      email: DataTypes.STRING,
      dob: DataTypes.STRING,
      user_type : DataTypes.INTEGER
    }
  );

  return UserDetails;
};
