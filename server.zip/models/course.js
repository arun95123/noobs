module.exports = (sequelize, DataTypes) => {
  const Course = sequelize.define('course', {
    course_name: {
      type: DataTypes.STRING,
      allowNull: false
    },
    start_date: {
      type: DataTypes.DATE
    },
    completion_date: {
      type: DataTypes.DATE
    },
    created_by : {
      type : DataTypes.INTEGER
    },
    instructorId:{
      type:DataTypes.INTEGER
    }
  });

  return Course;
};
