'use strict';
var bcrypt = require('bcrypt-nodejs');
var sequelize = require('./index');
var SALT_WORK_FACTOR = 10;

module.exports = (sequelize, DataTypes) => {
  var LoginDetails = sequelize.define('logindetails', {
      user_name: DataTypes.STRING,
      password: DataTypes.STRING,
    },
    {
      hooks: {
        beforeCreate: (user) => {
          console.log("check");
          const salt = bcrypt.genSaltSync();
          user.password = bcrypt.hashSync(user.password, salt);
        }
      }
    }
  );

  return LoginDetails;
};
