const Course = require('../models').course;
const UserDetails = require('../models').userdetails;

module.exports = (sequelize, dataTypes) => {
  const Announcement = sequelize.define('announcement', {
    announcement_title: {
      type: dataTypes.STRING,
      allowNull: false
    },
    announcement_content: {
      type: dataTypes.STRING
    },
    created_by : {
      type : dataTypes.INTEGER,
      allowNull: false
    },
    course_id:{
      type:dataTypes.INTEGER,
      allowNull: false
    }
  });

  Announcement.associate = function(models) {
    models.announcement.belongsTo(models.course, {foreignKey: 'course_id'});
    models.announcement.belongsTo(models.userdetails, {foreignKey: 'created_by'});
  };

  return Announcement;
};
